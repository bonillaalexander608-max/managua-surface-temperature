"""Reentrena XGBoost y comprueba el contraste retrospectivo de noviembre."""
from math import ceil
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score
from xgboost import XGBClassifier

RAIZ = Path(__file__).resolve().parent
DATOS = RAIZ / "data/panel_clasificacion_250m"
RESULTADOS = RAIZ / "resultados/contraste_2026-11-09_y_modelo_final"
FECHA = "2026-11-09"
OBJETIVO = "decil_caliente"
INDICES = ["ndvi_previo", "ndmi_previo"]
DISTANCIA = "distancia_xolotlan_km"
VARIABLES = ["recurrencia", "n_previas", "inicio_temporada", *INDICES, DISTANCIA]


def main():
    panel = pd.read_csv(
        DATOS / "optica_independiente_60d_v1/panel_optico_con_etiquetas.csv"
    )
    espacial = pd.read_csv(DATOS / "relieve_xolotlan_v1/predictores_espaciales_por_celda.csv")
    panel = panel.merge(espacial[["id_celda", DISTANCIA]], on="id_celda", validate="many_to_one")
    panel = panel.sort_values(["fecha", "id_celda"])
    panel["inicio_temporada"] = pd.to_datetime(panel["fecha"]).dt.month.isin([11, 12]).astype(int)
    panel.loc[~panel["apta_optica"].eq(True) | panel[INDICES].isna().any(axis=1), INDICES] = np.nan

    ajuste = panel.loc[panel["fecha"].lt(FECHA)].copy()
    prueba = panel.loc[panel["fecha"].eq(FECHA)].copy()
    por_celda = ajuste.groupby("id_celda", sort=False)[OBJETIVO]
    ajuste["n_previas"] = por_celda.cumcount()
    eventos_previos = por_celda.cumsum() - ajuste[OBJETIVO]
    ajuste["recurrencia"] = eventos_previos.div(ajuste["n_previas"].replace(0, np.nan)).fillna(0.10)
    historial = por_celda.agg(n_previas="size", recurrencia="mean")
    prueba = prueba.join(historial, on="id_celda", validate="many_to_one")
    prueba["n_previas"] = prueba["n_previas"].fillna(0)
    prueba["recurrencia"] = prueba["recurrencia"].fillna(0.10)

    modelo = XGBClassifier(
        objective="binary:logistic", eval_metric="logloss", n_estimators=200,
        max_depth=3, learning_rate=0.05, tree_method="hist", n_jobs=2,
        random_state=42,
    )
    modelo.fit(ajuste[VARIABLES], ajuste[OBJETIVO])
    prueba["puntaje_xgb"] = modelo.predict_proba(prueba[VARIABLES])[:, 1]
    guardado = pd.read_csv(RESULTADOS / "puntajes_y_observado_2026-11-09.csv")
    comparacion = prueba.set_index("id_celda").join(
        guardado.set_index("id_celda")[["recurrencia", "puntaje_xgb"]],
        rsuffix="_guardado", validate="one_to_one",
    )

    print(f"Escenas de ajuste: {ajuste['fecha'].nunique()}")
    print(f"Celdas de prueba: {len(prueba):,}")
    for columna in ("recurrencia", "puntaje_xgb"):
        orden = prueba.sort_values([columna, "id_celda"], ascending=[False, True])
        aciertos = [int(orden.head(ceil(p * len(prueba) / 100))[OBJETIVO].sum()) for p in (10, 20, 30)]
        ap = average_precision_score(prueba[OBJETIVO], prueba[columna])
        error = (comparacion[columna] - comparacion[f"{columna}_guardado"]).abs().max()
        print(f"{columna}: aciertos al 10/20/30 % {aciertos}, AP {ap:.6f}, diferencia máxima {error:.3g}")
        np.testing.assert_allclose(
            comparacion[columna], comparacion[f"{columna}_guardado"], atol=1e-6, rtol=0,
        )


if __name__ == "__main__":
    main()
